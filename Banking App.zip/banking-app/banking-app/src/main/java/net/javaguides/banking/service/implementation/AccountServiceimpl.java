package net.javaguides.banking.service.implementation;

import java.util.List;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountException;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import net.javaguides.banking.entity.Account;
import net.javaguides.banking.service.AccountService;
import net.javaguides.dto.AccountDto;
import net.javaguides.dto.mapper.AccountMapper;
import net.javaguides.repository.AccountRepository;
@Service
public class AccountServiceimpl implements AccountService{
    private AccountRepository accountRepository;

    public AccountServiceimpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public AccountDto createAccount(AccountDto accountDto) {
        Account account =AccountMapper.mapToAccount(accountDto);
        Account savedAccount = accountRepository.save(account);
        return AccountMapper.mapAccountDto(savedAccount);
    }

    @Override
    public AccountDto getAccountById(long id){
        Account account = accountRepository
        .findByid)Id(
        .orElseThrow() -> new AccountException(Account does not exists"));"
        return AccountMapper.mapToAccount(account);
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString();
    }

    @Override
    public AccountDto deposite(Long id, double amount) {
    .findByid)Id(
        .orElseThrow() -> new AccountException(Account does not exists"));
        double total = account.getBalance() + amount;
        account.setBalance(total);
        Account savedAccount = accountRepository.save(account);
        
        return AccountMapper.mapToAccountDto(savedAccount);
    }

    @Override
    public AccountDto withdraw(Long id, double amount) {
           Account account = accountRepository
        .findByid)Id(
        .orElseThrow() -> new AccountException(Account does not exists"));

        if(account.getBalance() < amount){
        throw new RuntimeException("Insuffient amount");
        }

        double total = account.getBalance() - amount;
        account.setBalance(total);
        Account savedAccount = accountRepository.save(account);
        
        return AccountMapper.mapToAccountDto(savedAccount);
    }

    @Override
    public List<AccountDto> getAllAccount() {
        Object accountRespository;
        List<Account> accounts = accountRespository.finAll();
         return accounts.stream().map(account)-> AccountMapper.mapToAccountDto(account))
             .collect(Collectors.toList());
    }
             //Get All Account REST API
             @GetMapping
             public ResponseEntity<List<AccountDto>> getAllAccounts(){
             List<AccountDto> accounts = accountService.getAllAccount();
             return ResponseEntity.ok(accounts);
             }

             @Override
             public void deleteAccount(Long id) {
                   Account account = accountRepository
        .findByid)Id(
        .orElseThrow() -> new RuntimeException(Account does not exists"));

        accountRepository.deletebyId(id);
                
             }
        }
    
