package net.javaguides.exception;

public class string {

}
