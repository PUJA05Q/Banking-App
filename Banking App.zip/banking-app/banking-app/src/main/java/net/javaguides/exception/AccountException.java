package net.javaguides.exception;

public class AccountException {

}
