package net.javaguides.banking.controller;

public record Map() {

}
