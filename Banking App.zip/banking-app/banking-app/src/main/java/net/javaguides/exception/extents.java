package net.javaguides.exception;

public class extents {

}
