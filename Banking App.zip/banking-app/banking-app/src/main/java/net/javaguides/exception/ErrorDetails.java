package net.javaguides.exception;

import java.time.LocalDateTime;

public record ErrorDetails(LocalDateTime timestamp,
string message,
string details, 
string errorecode) {

}
