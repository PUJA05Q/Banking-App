package net.javaguides.banking.service;

import net.javaguides.dto.AccountDto;

public interface AccountService {
    AccountDto createAccount(AccountDto account);

}
