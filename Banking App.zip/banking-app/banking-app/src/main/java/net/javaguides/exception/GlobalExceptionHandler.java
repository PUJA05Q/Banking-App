package net.javaguides.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.support.WebRequestDataBinder;

@ControllerAdvice
public class GlobalExceptionHandler {
    //Handel specific exception AccountException
    @ExceptionHandler(AccountException.class)
    public ResponseEntity<ErrorDetails> handleAccountException(AccountException exception,
    webRequest webRequest){
        ErrorDetails errorDetails = new ErrorDetails(
            LocalDataTime.now(),
            exception.getMessage(),
            webRequest.getDescription(false)
            "Account_NOT_FOUND" 
        );
        Return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }
    //Handel Generic exception
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorDetails> handelGenericException(Exception exception,
    webRequest webRequest){
        ErrorDetails errorDetails = new ErrorDetails(
            LocalDateTime.now(),
            exception.getMessage(),
                WebRequestDataBinder.getDescription(false),
            "INTERNAL_SERVER_ERROR"

        );
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    

}
